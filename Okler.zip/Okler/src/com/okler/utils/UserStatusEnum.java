package com.okler.utils;

public enum UserStatusEnum {
	NOT_REGISTERED,
	LOGGED_IN,
	LOGGED_IN_GOOGLE,
	LOGGED_IN_FB,
	LOGGED_IN_LINKEDIN,
	LOGGED_OUT
}
