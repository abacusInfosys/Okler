package com.okler.databeans;

import java.util.ArrayList;

public class JustViewedProdsDataBean {
	
	ArrayList<ProductDataBean> justViewedProdsList = new ArrayList<ProductDataBean>();

	public ArrayList<ProductDataBean> getJustViewedProdsList() {
		return justViewedProdsList;
	}

	public void setJustViewedProdsList(ArrayList<ProductDataBean> justViewedProdsList) {
		this.justViewedProdsList = justViewedProdsList;
	}
	
	

}
