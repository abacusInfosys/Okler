package com.okler.databeans;

public class BrandsDataBean {
String brandId,brandName;

public String getBrandId() {
	return brandId;
}

public void setBrandId(String brandId) {
	this.brandId = brandId;
}

public String getBrandName() {
	return brandName;
}

public void setBrandName(String brandName) {
	this.brandName = brandName;
}
}
