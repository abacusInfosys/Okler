package com.okler.databeans;

public class FavouritesDataBean {
	
	String prod_id;

	public String getProd_id() {
		return prod_id;
	}

	public void setProd_id(String prod_id) {
		this.prod_id = prod_id;
	}
	

}
