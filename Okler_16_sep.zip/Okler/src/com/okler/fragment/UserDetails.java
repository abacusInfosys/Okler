package com.okler.fragment;

public class UserDetails {

}
