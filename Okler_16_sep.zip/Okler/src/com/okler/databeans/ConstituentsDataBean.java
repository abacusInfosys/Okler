package com.okler.databeans;

public class ConstituentsDataBean {
	
	String constituent_name="",contra_indication="",caution="",side_effect="",indication="";
	
	
	

	public String getIndication() {
		return indication;
	}

	public void setIndication(String indication) {
		this.indication = indication;
	}

	public String getConstituent_name() {
		return constituent_name;
	}

	public void setConstituent_name(String constituent_name) {
		this.constituent_name = constituent_name;
	}

	public String getContra_indication() {
		return contra_indication;
	}

	public void setContra_indication(String contra_indication) {
		this.contra_indication = contra_indication;
	}

	public String getCaution() {
		return caution;
	}

	public void setCaution(String caution) {
		this.caution = caution;
	}

	public String getSide_effect() {
		return side_effect;
	}

	public void setSide_effect(String side_effect) {
		this.side_effect = side_effect;
	}
	
	
	

}
