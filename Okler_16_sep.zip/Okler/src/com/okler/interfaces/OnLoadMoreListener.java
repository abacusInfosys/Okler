package com.okler.interfaces;

public interface OnLoadMoreListener {
	void onLoadMore();
}
