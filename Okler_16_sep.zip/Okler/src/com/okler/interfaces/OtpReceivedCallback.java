package com.okler.interfaces;

public interface OtpReceivedCallback {

	void otpReceived();
}
