package com.okler.interfaces;

public interface ClearHistoryCallback {

	void disableClearHistory();
}
