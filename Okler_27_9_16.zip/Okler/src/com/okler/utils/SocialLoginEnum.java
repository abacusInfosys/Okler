package com.okler.utils;

public enum SocialLoginEnum {
	SIGNUP,
	SIGNIN,
}
