package com.okler.enums;

public enum DiagnoOrderPickUpType {
HOME,
LAB
}
