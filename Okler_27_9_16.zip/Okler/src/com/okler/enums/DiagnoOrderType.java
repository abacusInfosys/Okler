package com.okler.enums;

public enum DiagnoOrderType {
TEST,
PACKAGE
}
