package com.okler.databeans;

public class SubCategoriesDataBean {

	String subCateId, subCateName,cateId,cateName;

	public String getSubCateId() {
		return subCateId;
	}

	public void setSubCateId(String subCateId) {
		this.subCateId = subCateId;
	}

	public String getSubCateName() {
		return subCateName;
	}

	public void setSubCateName(String subCateName) {
		this.subCateName = subCateName;
	}

	public String getCateId() {
		return cateId;
	}

	public void setCateId(String cateId) {
		this.cateId = cateId;
	}

	public String getCateName() {
		return cateName;
	}

	public void setCateName(String cateName) {
		this.cateName = cateName;
	}
	
}
